export const feedback = [
    {
        fid:'322',
        feed:'Super College',
        sid:501
    },
    {
        fid:'323',
        feed:'Super College and best premises',
        sid:502
    },
]