export const marks = [
  {
    mid: 701,
    sid: 501,
    eng: 86,
    marathi: 77,
    science: 63,
    math: 95,
    social: 59,
    totalMarks: 380,
    grade: "O",
  },
  {
    mid: 702,
    sid: 502,
    eng: 86,
    marathi: 76,
    science: 63,
    math: 95,
    social: 59,
    totalMarks: 379,
    grade: "O",
  },
];
