export const students = [
  {
    sid: 501,
    sname: "Mayuri Mendhkar",
    age: 23,
    email: "mayurimendhkar0618@gmail.com",
    password: "Mayuri@1234",
    sclass: "bcom",
    section: "arts",
  },
  {
    sid: 502,
    sname: "Vishwajit Aher",
    age: 23,
    email: "vishwajitaher99@gmail.com",
    password: "Vishwajit@1234",
    sclass: "ba",
    section: "commerce",
  },
];
