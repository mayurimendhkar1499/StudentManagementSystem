package com.main.SpringBootStudentAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootStudentApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
